import * as vscode from 'vscode';
import { LanguageClientHandle } from '../services/languageClientHandle';

export class LanguageServerCommandHandler {
    public constructor(private readonly languageClient: LanguageClientHandle) {
    }

    public register(context: vscode.ExtensionContext): void {
        context.subscriptions.push(
            vscode.commands.registerTextEditorCommand('nexusPascal.code.complete', this.codeComplete)
        );
    }

    private codeComplete = (textEditor: vscode.TextEditor): void => {
        this.languageClient.completeCode(textEditor);
    };
}
