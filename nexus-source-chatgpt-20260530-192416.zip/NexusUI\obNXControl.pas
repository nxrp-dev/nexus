unit obNXControl;
{$mode objfpc}{$H+}
{$interfaces corba}

interface

uses Classes, SysUtils, Math, fgl, obNXCanvas, obNXFont, obNXPersist,
  obNXSkin, tpNXEvents, tpNXLayout, tpNXPlatform, obNXPlatform;

type
  TNXControl = class;
  TNXControlList = specialize TFPGObjectList<TNXControl>;
  TNXHitTestResult = (htNone, htTarget, htBlocked);
  INXControlParent = interface
    procedure AddChild(AChild: TNXControl);
    procedure ChildDestroying(AChild: TNXControl);
    procedure ChildInputStateChanged(AChild: TNXControl);
    procedure ClearChildFocus;
    procedure FocusChild(AChild: TNXControl);
    procedure FreeChild(AChild: TNXControl);
    procedure LayoutChildren;
    function GetAbsChildClipRect: TNXRect;
    function GetAbsLeft: Integer;
    function GetAbsTop: Integer;
    function GetCanvas: TNXCanvas;
    function GetChildOriginX(AChild: TNXControl): Integer;
    function GetChildOriginY(AChild: TNXControl): Integer;
    function GetChildLayoutHeight(AChild: TNXControl): Integer;
    function GetChildLayoutWidth(AChild: TNXControl): Integer;
    function GetChildren: TNXControlList;
    function GetFontForChildren: TNXFont;
    function GetHeight: Integer;
    function GetSkin: TNXSkin;
    function GetWidth: Integer;
    function IsChildEffectivelyEnabled(AChild: TNXControl): Boolean;
    function IsChildEffectivelyVisible(AChild: TNXControl): Boolean;
    function ContainsScreenPoint(AX, AY: Integer): Boolean;
    function LocalToScreen(AX, AY: Integer): TNXPoint;
    function ScreenToLocal(AX, AY: Integer): TNXPoint;
    property AbsLeft: Integer read GetAbsLeft;
    property AbsTop: Integer read GetAbsTop;
    property Canvas: TNXCanvas read GetCanvas;
    property Children: TNXControlList read GetChildren;
    property FontForChildren: TNXFont read GetFontForChildren;
    property Height: Integer read GetHeight;
    property Skin: TNXSkin read GetSkin;
    property Width: Integer read GetWidth;
  end;
  TNXMouseEvent = procedure(Sender: TObject; X, Y: Integer; Button: TNXMouseButton) of object;
  TNXMouseMotionEvent = procedure(Sender: TObject; X, Y: Integer; ButtonState: TNXMouseButtons) of object;
  TNXMouseWheelEvent = procedure(Sender: TObject; X, Y, ADeltaX, ADeltaY: Integer) of object;
  TNXTextInputEvent = procedure(Sender: TObject; const AText: string) of object;
  TNXKeyEvent = procedure(Sender: TObject; const AEvent: TNXKeyEventData) of object;

  TNXControlHost = class(TNXPersistObject, INXControlParent)
  private
    FChildren: TNXControlList;
    FCanvas: TNXCanvas;
    FHoverPath: TList;
    FLayoutBottom: Integer;
    FLayoutLeft: Integer;
    FLayoutRight: Integer;
    FLayoutTop: Integer;
    FLayouting: Boolean;
    FPressedControls: array[TNXMouseButton] of TNXControl;
    FPressedPaths: array[TNXMouseButton] of TList;

    function EnsureHoverPath: TList;
    function EnsurePressedPath(AButton: TNXMouseButton): TList;
    function FocusableControlFromPath(APath: TList): TNXControl;
    function PathContainsControl(APath: TList; AControl: TNXControl): Boolean;
    procedure ClearInteractionStateFor(AControl: TNXControl;
      ANotifyHoverExit: Boolean);
    procedure ClearLocalInputStateFor(AControl: TNXControl);
    procedure ClearPressedPath(AButton: TNXMouseButton);
    procedure DeliverMouseDownPath(APath: TList; AX, AY: Integer;
      AButton: TNXMouseButton);
    procedure DeliverMouseMotionPath(APath: TList; AX, AY: Integer;
      AButtonState: TNXMouseButtons);
    procedure DeliverMouseUpPath(APath: TList; AX, AY: Integer;
      AButton: TNXMouseButton);
    procedure DeliverMouseWheelPath(APath: TList; AX, AY, ADeltaX,
      ADeltaY: Integer);
    procedure SetHoverPath(APath: TList);
    procedure StorePressedPath(AButton: TNXMouseButton; APath: TList);
  protected
    procedure SetCanvas(ACanvas: TNXCanvas); virtual;

    function GetAbsChildClipRect: TNXRect; virtual;
    function GetAbsEffectiveHitRect: TNXRect; virtual;
    function GetAbsHitRect: TNXRect; virtual;
    function GetAbsLeft: Integer; virtual; abstract;
    function GetAbsTop: Integer; virtual; abstract;
    function GetCanvas: TNXCanvas; virtual;
    function GetChildAreaLeft: Integer; virtual; abstract;
    function GetChildAreaTop: Integer; virtual; abstract;
    function GetChildOriginX(AChild: TNXControl): Integer; virtual;
    function GetChildOriginY(AChild: TNXControl): Integer; virtual;
    function GetChildAreaHeight: Integer; virtual; abstract;
    function GetChildAreaWidth: Integer; virtual; abstract;
    function GetChildLayoutHeight(AChild: TNXControl): Integer; virtual;
    function GetChildLayoutWidth(AChild: TNXControl): Integer; virtual;
    function GetChildren: TNXControlList; virtual;
    function GetFontForChildren: TNXFont; virtual; abstract;
    function GetHeight: Integer; virtual; abstract;
    function GetSkin: TNXSkin; virtual; abstract;
    function GetWidth: Integer; virtual; abstract;
    function ControlContains(AParent, AControl: TNXControl): Boolean; virtual;
    function HitTestChildren: Boolean; virtual;
    function HitTestChildrenScreen(AX, AY: Integer; const AClipRect: TNXRect;
      APath: TList): TNXHitTestResult; virtual;
    function HitTestSelf(AX, AY: Integer): Boolean; virtual;
  public
    constructor Create; override;
    destructor Destroy; override;

    procedure AddChild(AChild: TNXControl); virtual;
    function BuildHitPathScreen(AX, AY: Integer;
      APath: TList): TNXHitTestResult; virtual;
    procedure ChildDestroying(AChild: TNXControl); virtual;
    procedure ChildInputStateChanged(AChild: TNXControl); virtual;
    procedure ClearMouseHover; virtual;
    procedure ClearChildFocus; virtual;
    function ContainsLocalPoint(AX, AY: Integer): Boolean; virtual;
    function ContainsScreenPoint(AX, AY: Integer): Boolean; virtual;
    procedure DispatchMouseDownScreen(AX, AY: Integer;
      AButton: TNXMouseButton); virtual;
    procedure DispatchMouseMotionScreen(AX, AY: Integer;
      AButtonState: TNXMouseButtons); virtual;
    procedure DispatchMouseUpScreen(AX, AY: Integer;
      AButton: TNXMouseButton); virtual;
    procedure DispatchMouseWheelScreen(AX, AY, ADeltaX,
      ADeltaY: Integer); virtual;
    procedure FocusChild(AChild: TNXControl); virtual;
    procedure FreeChild(AChild: TNXControl); virtual;
    function HasPressedControl(AButton: TNXMouseButton): Boolean; virtual;
    function HitTestScreen(AX, AY: Integer): TNXControl; virtual;
    function IsChildEffectivelyEnabled(AChild: TNXControl): Boolean; virtual;
    function IsChildEffectivelyVisible(AChild: TNXControl): Boolean; virtual;
    procedure LayoutChildren; virtual;
    function LocalToScreen(AX, AY: Integer): TNXPoint; virtual;
    function ScreenToLocal(AX, AY: Integer): TNXPoint; virtual;
    procedure SendSizeCallback; virtual;

    property AbsChildClipRect: TNXRect read GetAbsChildClipRect;
    property AbsEffectiveHitRect: TNXRect read GetAbsEffectiveHitRect;
    property AbsHitRect: TNXRect read GetAbsHitRect;
    property AbsLeft: Integer read GetAbsLeft;
    property AbsTop: Integer read GetAbsTop;
    property Canvas: TNXCanvas read GetCanvas write SetCanvas;
    property Children: TNXControlList read GetChildren;
    property FontForChildren: TNXFont read GetFontForChildren;
    property Height: Integer read GetHeight;
    property Skin: TNXSkin read GetSkin;
    property Width: Integer read GetWidth;
  end;

  TNXControl = class(TNXControlHost)
  private
    FCanFocus, FDestroying, FEnabled, FFocused, FMouseEntered,
      FReceiveAllEvents, FTabStop: Boolean;
    FVisible: Boolean;
    FHeight, FLeft, FTop, FWidth: integer;
    FAlign: TNXControlAlign;
    FAnchors: TNXControlAnchors;
    FAnchorBottom: Integer;
    FAnchorLeft: Integer;
    FAnchorRight: Integer;
    FAnchorTop: Integer;
    FHasLastClick: Boolean;
    FLastClickButton: TNXMouseButton;
    FLastClickTicks: UInt32;
    FLastClickX, FLastClickY: Integer;
    FOnKeyDown: TNXKeyEvent;
    FOnKeyUp: TNXKeyEvent;
    FOnFocus: TNotifyEvent;
    FOnLoseFocus: TNotifyEvent;
    FOnMouseClick: TNXMouseEvent;
    FOnMouseDoubleClick: TNXMouseEvent;
    FOnMouseDown: TNXMouseEvent;
    FOnMouseEnter: TNotifyEvent;
    FOnMouseExit: TNotifyEvent;
    FOnMouseMotion: TNXMouseMotionEvent;
    FOnMouseUp: TNXMouseEvent;
    FOnMouseWheel: TNXMouseWheelEvent;
    FOnResize: TNotifyEvent;
    FOnTextInput: TNXTextInputEvent;
    FParent: INXControlParent;
    FFont: TNXFont;
    FMetricFont: TNXFont;
    FSkinClass: string;
  protected
    FBackColor: TNXColor;
    FForeColor: TNXColor;
    FActiveColor: TNXColor;
    CurFillColor: TNXColor;
    CurBorderColor: TNXColor;
    FFillStyle: TFillStyle;
    FCaption: string;
    FBorderStyle: TBorderStyle;
    FBorderColor: TNXColor;
    FontHeight, FontAscent, FontDescent, FontLineSkip: Integer;
    FontMonospace: Integer;
    ButtonStates: TNXMouseButtons;
    procedure SetWidth(AWidth: integer); virtual;
    procedure SetHeight(AHeight: integer); virtual;
    procedure SetAlign(AValue: TNXControlAlign); virtual;
    procedure SetAnchors(AValue: TNXControlAnchors); virtual;
    procedure SetEnabled(AValue: Boolean); virtual;
    procedure SetFocused(AValue: Boolean); virtual;
    procedure SetVisible(AValue: Boolean); virtual;
    procedure PropagateParentContext; virtual;
    procedure AttachToParent(const AParent: INXControlParent); virtual;
    procedure BringToFront; virtual;
    procedure CaptureMouse; virtual;
    procedure ReleaseMouseCapture; virtual;
    function HasMouseCapture: Boolean; virtual;

    function GetAbsLeft: Integer; override;
    function GetAbsTop: Integer; override;
    function GetAbsBoundsRect: TNXRect; virtual;
    function GetAbsEffectiveHitRect: TNXRect; override;
    function GetAbsContentRect: TNXRect; virtual;
    function GetAbsClientRect: TNXRect; virtual;
    function GetBoundsRect: TNXRect; virtual;
    function GetBorderThickness: Integer; virtual;
    function GetClientRect: TNXRect; virtual;
    function GetChildAreaLeft: Integer; override;
    function GetChildAreaTop: Integer; override;
    function GetChildAreaHeight: Integer; override;
    function GetChildAreaWidth: Integer; override;
    function GetContentRect: TNXRect; virtual;
    function GetFont: TNXFont; virtual;
    function GetFontForChildren: TNXFont; override;
    function GetHeight: Integer; override;
    function GetLeft: Integer; virtual;
    function GetPlatform: TNXPlatform; virtual;
    function GetSkin: TNXSkin; override;
    function GetTop: Integer; virtual;
    function GetWidth: Integer; override;
    procedure SetLeft(AValue: Integer); virtual;
    procedure SetTop(AValue: Integer); virtual;
    procedure SetBoundsInternal(ALeft, ATop, AWidth, AHeight: Integer;
      AUpdateAnchors: Boolean); virtual;
    procedure SetBackColor(InColor: TNXColor);
    procedure SetBorderColor(InColor: TNXColor);
    procedure SetFont(AFont: TNXFont); virtual;
    procedure UpdateFontMetrics(AFont: TNXFont); virtual;

    function LocalRectToAbs(const ARect: TNXRect): TNXRect; virtual;
    procedure RenderRect(const ARect: TNXRect; AColor: TNXColor); overload;
    procedure RenderFilledRect(const ARect: TNXRect; AColor: TNXColor); overload;
    procedure RenderLine(AX0, AY0, AX1, AY1: Integer; AColor: TNXColor);
    procedure RenderText(AText: string; AX, AY: Integer; AAlignment: TTextAlign);
    procedure RenderClient; virtual;
    function HitTestSelf(AX, AY: Integer): Boolean; override;

    procedure DoMouseEnter; virtual;
    procedure DoMouseExit; virtual;
    procedure DoMouseDown(X, Y: Integer; Button: TNXMouseButton); virtual;
    procedure DoMouseUp(X, Y: Integer; Button: TNXMouseButton); virtual;
    procedure DoMouseMotion(X, Y: Integer; ButtonState: TNXMouseButtons); virtual;
    procedure DoMouseWheel(X, Y, ADeltaX, ADeltaY: Integer); virtual;
    procedure DoTextInput(const AText: string); virtual;
    procedure DoMouseClick(X, Y: Integer; Button: TNXMouseButton); virtual;
    procedure DoMouseDoubleClick(X, Y: Integer; Button: TNXMouseButton); virtual;
    procedure DoFocus; virtual;
    procedure DoLoseFocus; virtual;
    procedure DoKeyDown(const AEvent: TNXKeyEventData); virtual;
    procedure DoKeyUp(const AEvent: TNXKeyEventData); virtual;
    procedure DoResize; virtual;
  public
    procedure SetParent(const AParent: INXControlParent); virtual;
    procedure ChildDestroying(AChild: TNXControl); override;
    procedure ChildInputStateChanged(AChild: TNXControl); override;
    procedure Focus; virtual;
    procedure FocusChild(AChild: TNXControl); override;
    procedure SetBounds(ALeft, ATop, AWidth, AHeight: Integer); virtual;
    procedure Paint; virtual;
    procedure Render; virtual;
    procedure ctrl_FontChanged; virtual;
    constructor Create(const AParent: INXControlParent); overload; virtual;
    constructor Create(const AParent: INXControlParent; const ARect: TNXRect); overload; virtual;
    destructor Destroy; override;
    procedure ParentSizeCallback(AWidth, AHeight: Integer); virtual;
    procedure ChildAddedCallback; virtual;
    property MouseEntered: Boolean read FMouseEntered;
    function FindFocusableControlAt(X, Y: Integer): TNXControl; virtual;

    procedure ProcessMouseEnter; virtual;
    procedure ProcessMouseExit; virtual;
    procedure ProcessMouseDown(X, Y: Integer; Button: TNXMouseButton); virtual;
    procedure ProcessMouseUp(X, Y: Integer; Button: TNXMouseButton); virtual;
    procedure ProcessMouseMotion(X, Y: Integer; ButtonState: TNXMouseButtons); virtual;
    procedure ProcessMouseWheel(X, Y, ADeltaX, ADeltaY: Integer); virtual;
    procedure ProcessTextInput(const AText: string); virtual;
    procedure ProcessMouseClick(X, Y: Integer; Button: TNXMouseButton); virtual;
    procedure ProcessFocus; virtual;
    procedure ProcessLoseFocus; virtual;
    procedure ProcessKeyDown(const AEvent: TNXKeyEventData); virtual;
    procedure ProcessKeyUp(const AEvent: TNXKeyEventData); virtual;
    procedure ProcessResize; virtual;
    function IsChildEffectivelyEnabled(AChild: TNXControl): Boolean; override;
    function IsChildEffectivelyVisible(AChild: TNXControl): Boolean; override;
    function IsEffectivelyEnabled: Boolean; virtual;
    function IsEffectivelyVisible: Boolean; virtual;
    function IsInputEligible: Boolean; virtual;

    property AbsLeft: Integer read GetAbsLeft;
    property AbsBoundsRect: TNXRect read GetAbsBoundsRect;
    property AbsClientRect: TNXRect read GetAbsClientRect;
    property AbsContentRect: TNXRect read GetAbsContentRect;
    property AbsTop: Integer read GetAbsTop;
    property ActiveColor: TNXColor read FActiveColor write FActiveColor;
    property Align: TNXControlAlign read FAlign write SetAlign;
    property Anchors: TNXControlAnchors read FAnchors write SetAnchors;
    property BackColor: TNXColor read FBackColor write SetBackColor;
    property BorderColor: TNXColor read FBorderColor write SetBorderColor;
    property BorderStyle: TBorderStyle read FBorderStyle write FBorderStyle;
    property BoundsRect: TNXRect read GetBoundsRect;
    property Caption: string read FCaption write FCaption;
    property Children: TNXControlList read GetChildren;
    property ClientRect: TNXRect read GetClientRect;
    property ContentRect: TNXRect read GetContentRect;
    property Enabled: Boolean read FEnabled write SetEnabled;
    property FillStyle: TFillStyle read FFillStyle write FFillStyle;
    property Font: TNXFont read GetFont write SetFont;
    property FontForChildren: TNXFont read GetFontForChildren;
    property ForeColor: TNXColor read FForeColor write FForeColor;
    property Height: Integer read FHeight write SetHeight;
    property Left: Integer read GetLeft write SetLeft;
    property OnKeyDown: TNXKeyEvent read FOnKeyDown write FOnKeyDown;
    property OnKeyUp: TNXKeyEvent read FOnKeyUp write FOnKeyUp;
    property OnFocus: TNotifyEvent read FOnFocus write FOnFocus;
    property OnLoseFocus: TNotifyEvent read FOnLoseFocus write FOnLoseFocus;
    property OnMouseClick: TNXMouseEvent read FOnMouseClick write FOnMouseClick;
    property OnMouseDoubleClick: TNXMouseEvent read FOnMouseDoubleClick write FOnMouseDoubleClick;
    property OnMouseDown: TNXMouseEvent read FOnMouseDown write FOnMouseDown;
    property OnMouseEnter: TNotifyEvent read FOnMouseEnter write FOnMouseEnter;
    property OnMouseExit: TNotifyEvent read FOnMouseExit write FOnMouseExit;
    property OnMouseMotion: TNXMouseMotionEvent read FOnMouseMotion write FOnMouseMotion;
    property OnMouseUp: TNXMouseEvent read FOnMouseUp write FOnMouseUp;
    property OnMouseWheel: TNXMouseWheelEvent read FOnMouseWheel write FOnMouseWheel;
    property OnResize: TNotifyEvent read FOnResize write FOnResize;
    property OnTextInput: TNXTextInputEvent read FOnTextInput write FOnTextInput;
    property Parent: INXControlParent read FParent;
    property ReceiveAllEvents: Boolean read FReceiveAllEvents write FReceiveAllEvents;
    property Canvas: TNXCanvas read GetCanvas write SetCanvas;
    property CanFocus: Boolean read FCanFocus write FCanFocus;
    property IsFocused: Boolean read FFocused write SetFocused;
    property IsDestroying: Boolean read FDestroying;
    property Skin: TNXSkin read GetSkin;
    property SkinClass: string read FSkinClass write FSkinClass;
    property TabStop: Boolean read FTabStop write FTabStop;
    property Top: Integer read GetTop write SetTop;
    property Visible: Boolean read FVisible write SetVisible;
    property Width: Integer read FWidth write SetWidth;
  end;

function NXCapturedMouseControl: TNXControl;

implementation

uses
  obNXApplication;

var
  GCapturedMouseControl: TNXControl = nil;

const
  cDoubleClickMaxMS = 500;
  cDoubleClickMaxDistance = 4;

function NXCapturedMouseControl: TNXControl;
begin
  Result := GCapturedMouseControl;
end;

function TNXControlHost.EnsureHoverPath: TList;
begin
  if not Assigned(FHoverPath) then
    FHoverPath := TList.Create;

  Result := FHoverPath;
end;

function TNXControlHost.EnsurePressedPath(AButton: TNXMouseButton): TList;
begin
  if not Assigned(FPressedPaths[AButton]) then
    FPressedPaths[AButton] := TList.Create;

  Result := FPressedPaths[AButton];
end;

function TNXControlHost.FocusableControlFromPath(APath: TList): TNXControl;
var
  lControl: TNXControl;
  lIndex: Integer;
begin
  Result := nil;
  if not Assigned(APath) then
    Exit;

  for lIndex := APath.Count - 1 downto 0 do
  begin
    lControl := TNXControl(APath[lIndex]);
    if Assigned(lControl) and lControl.IsInputEligible and
      lControl.CanFocus then
    begin
      Result := lControl;
      Exit;
    end;
  end;
end;

function TNXControlHost.PathContainsControl(APath: TList;
  AControl: TNXControl): Boolean;
var
  lIndex: Integer;
begin
  Result := False;
  if (not Assigned(APath)) or (not Assigned(AControl)) then
    Exit;

  for lIndex := 0 to APath.Count - 1 do
  begin
    if ControlContains(AControl, TNXControl(APath[lIndex])) then
    begin
      Result := True;
      Exit;
    end;
  end;
end;

procedure TNXControlHost.ClearInteractionStateFor(AControl: TNXControl;
  ANotifyHoverExit: Boolean);
var
  lButton: TNXMouseButton;
  lHoverIndex: Integer;
  lIndex: Integer;
begin
  if not Assigned(AControl) then
    Exit;

  if ANotifyHoverExit then
    ClearLocalInputStateFor(AControl);

  if Assigned(FHoverPath) then
  begin
    lHoverIndex := -1;
    for lIndex := 0 to FHoverPath.Count - 1 do
    begin
      if ControlContains(AControl, TNXControl(FHoverPath[lIndex])) then
      begin
        lHoverIndex := lIndex;
        Break;
      end;
    end;

    if (lHoverIndex >= 0) and (lHoverIndex < FHoverPath.Count) then
    begin
      if ANotifyHoverExit then
        while FHoverPath.Count > lHoverIndex do
        begin
          TNXControl(FHoverPath[FHoverPath.Count - 1]).ProcessMouseExit;
          FHoverPath.Delete(FHoverPath.Count - 1);
        end
      else
        while FHoverPath.Count > lHoverIndex do
          FHoverPath.Delete(FHoverPath.Count - 1);
    end;
  end;

  for lButton := Low(TNXMouseButton) to High(TNXMouseButton) do
  begin
    if ControlContains(AControl, FPressedControls[lButton]) then
      FPressedControls[lButton] := nil;

    if PathContainsControl(FPressedPaths[lButton], AControl) then
      ClearPressedPath(lButton);
  end;

  if ControlContains(AControl, GCapturedMouseControl) then
    GCapturedMouseControl := nil;
end;

procedure TNXControlHost.ClearLocalInputStateFor(AControl: TNXControl);
var
  lIndex: Integer;
begin
  if not Assigned(AControl) then
    Exit;

  AControl.ButtonStates := [];
  if AControl.IsFocused then
    AControl.IsFocused := False;

  for lIndex := 0 to AControl.Children.Count - 1 do
    ClearLocalInputStateFor(AControl.Children[lIndex]);
end;

procedure TNXControlHost.ClearPressedPath(AButton: TNXMouseButton);
begin
  FPressedControls[AButton] := nil;
  if Assigned(FPressedPaths[AButton]) then
    FPressedPaths[AButton].Clear;
end;

procedure TNXControlHost.DeliverMouseDownPath(APath: TList; AX, AY: Integer;
  AButton: TNXMouseButton);
var
  lControl: TNXControl;
  lIndex: Integer;
  lPoint: TNXPoint;
begin
  if not Assigned(APath) then
    Exit;

  for lIndex := APath.Count - 1 downto 0 do
  begin
    lControl := TNXControl(APath[lIndex]);
    if (lIndex = APath.Count - 1) or
      (lControl.ReceiveAllEvents and
      ((lIndex <> 0) or (TObject(lControl) <> Self) or
      (APath.Count = 1))) then
    begin
      lPoint := lControl.ScreenToLocal(AX, AY);
      lControl.ProcessMouseDown(lPoint.x, lPoint.y, AButton);
    end;
  end;
end;

procedure TNXControlHost.DeliverMouseMotionPath(APath: TList; AX,
  AY: Integer; AButtonState: TNXMouseButtons);
var
  lControl: TNXControl;
  lIndex: Integer;
  lPoint: TNXPoint;
begin
  if not Assigned(APath) then
    Exit;

  for lIndex := APath.Count - 1 downto 0 do
  begin
    lControl := TNXControl(APath[lIndex]);
    if (lIndex = APath.Count - 1) or
      (lControl.ReceiveAllEvents and
      ((lIndex <> 0) or (TObject(lControl) <> Self) or
      (APath.Count = 1))) then
    begin
      lPoint := lControl.ScreenToLocal(AX, AY);
      lControl.ProcessMouseMotion(lPoint.x, lPoint.y, AButtonState);
    end;
  end;
end;

procedure TNXControlHost.DeliverMouseUpPath(APath: TList; AX, AY: Integer;
  AButton: TNXMouseButton);
var
  lControl: TNXControl;
  lIndex: Integer;
  lPoint: TNXPoint;
begin
  if not Assigned(APath) then
    Exit;

  for lIndex := APath.Count - 1 downto 0 do
  begin
    lControl := TNXControl(APath[lIndex]);
    if (lIndex = APath.Count - 1) or
      (lControl.ReceiveAllEvents and
      ((lIndex <> 0) or (TObject(lControl) <> Self) or
      (APath.Count = 1))) then
    begin
      lPoint := lControl.ScreenToLocal(AX, AY);
      lControl.ProcessMouseUp(lPoint.x, lPoint.y, AButton);
    end;
  end;
end;

procedure TNXControlHost.DeliverMouseWheelPath(APath: TList; AX, AY, ADeltaX,
  ADeltaY: Integer);
var
  lControl: TNXControl;
  lIndex: Integer;
  lPoint: TNXPoint;
begin
  if not Assigned(APath) then
    Exit;

  for lIndex := APath.Count - 1 downto 0 do
  begin
    lControl := TNXControl(APath[lIndex]);
    if (lIndex = APath.Count - 1) or
      (lControl.ReceiveAllEvents and
      ((lIndex <> 0) or (TObject(lControl) <> Self) or
      (APath.Count = 1))) then
    begin
      lPoint := lControl.ScreenToLocal(AX, AY);
      lControl.ProcessMouseWheel(lPoint.x, lPoint.y, ADeltaX, ADeltaY);
    end;
  end;
end;

procedure TNXControlHost.SetHoverPath(APath: TList);
var
  lCommonCount: Integer;
  lHoverPath: TList;
  lIndex: Integer;
begin
  lHoverPath := EnsureHoverPath;
  lCommonCount := 0;

  while (lCommonCount < lHoverPath.Count) and
    Assigned(APath) and (lCommonCount < APath.Count) and
    (lHoverPath[lCommonCount] = APath[lCommonCount]) do
    Inc(lCommonCount);

  for lIndex := lHoverPath.Count - 1 downto lCommonCount do
    if Assigned(lHoverPath[lIndex]) then
      TNXControl(lHoverPath[lIndex]).ProcessMouseExit;

  if Assigned(APath) then
  begin
    for lIndex := lCommonCount to APath.Count - 1 do
      if Assigned(APath[lIndex]) then
        TNXControl(APath[lIndex]).ProcessMouseEnter;

    lHoverPath.Clear;
    for lIndex := 0 to APath.Count - 1 do
      lHoverPath.Add(APath[lIndex]);
  end
  else
    lHoverPath.Clear;
end;

procedure TNXControlHost.StorePressedPath(AButton: TNXMouseButton;
  APath: TList);
var
  lIndex: Integer;
  lPressedPath: TList;
begin
  lPressedPath := EnsurePressedPath(AButton);
  lPressedPath.Clear;

  if not Assigned(APath) then
    Exit;

  for lIndex := 0 to APath.Count - 1 do
    lPressedPath.Add(APath[lIndex]);
end;

constructor TNXControlHost.Create;
begin
  inherited Create;
  FChildren := TNXControlList.Create(True);
  FLayoutLeft := 0;
  FLayoutTop := 0;
  FLayoutRight := 0;
  FLayoutBottom := 0;
end;

destructor TNXControlHost.Destroy;
var
  lButton: TNXMouseButton;
begin
  FreeAndNil(FHoverPath);
  for lButton := Low(TNXMouseButton) to High(TNXMouseButton) do
    FreeAndNil(FPressedPaths[lButton]);

  FreeAndNil(FChildren);
  inherited Destroy;
end;

procedure TNXControlHost.AddChild(AChild: TNXControl);
begin
  if not Assigned(AChild) then
    Exit;

  if Children.IndexOf(AChild) >= 0 then
  begin
    Exit;
  end;

  if Assigned(AChild.Parent) then
    raise Exception.Create('Cannot add child that is already attached to another parent');

  Children.Add(AChild);
  AChild.SetParent(INXControlParent(Self));
  AChild.ChildAddedCallback;
  LayoutChildren;
end;

procedure TNXControlHost.ChildDestroying(AChild: TNXControl);
begin
  ClearInteractionStateFor(AChild, False);
end;

procedure TNXControlHost.ChildInputStateChanged(AChild: TNXControl);
begin
  ClearInteractionStateFor(AChild, True);
end;

function TNXControlHost.GetAbsChildClipRect: TNXRect;
begin
  Result := MakeNXRect(AbsLeft + GetChildAreaLeft, AbsTop + GetChildAreaTop,
    Max(0, GetChildAreaWidth), Max(0, GetChildAreaHeight));
end;

function TNXControlHost.GetAbsEffectiveHitRect: TNXRect;
begin
  Result := AbsHitRect;
end;

function TNXControlHost.GetAbsHitRect: TNXRect;
begin
  Result := MakeNXRect(AbsLeft, AbsTop, Max(0, Width), Max(0, Height));
end;

procedure TNXControlHost.ClearChildFocus;
var
  lIndex: Integer;
begin
  for lIndex := 0 to Children.Count - 1 do
    Children[lIndex].IsFocused := False;
end;

procedure TNXControlHost.ClearMouseHover;
var
  lHoverPath: TList;
  lIndex: Integer;
begin
  lHoverPath := EnsureHoverPath;
  for lIndex := lHoverPath.Count - 1 downto 0 do
    if Assigned(lHoverPath[lIndex]) then
      TNXControl(lHoverPath[lIndex]).ProcessMouseExit;

  lHoverPath.Clear;
end;

function TNXControlHost.ContainsLocalPoint(AX, AY: Integer): Boolean;
begin
  Result := (AX >= 0) and (AX < Width) and (AY >= 0) and (AY < Height);
end;

function TNXControlHost.ContainsScreenPoint(AX, AY: Integer): Boolean;
var
  lPoint: TNXPoint;
begin
  lPoint := ScreenToLocal(AX, AY);
  Result := ContainsLocalPoint(lPoint.x, lPoint.y);
end;

function TNXControlHost.BuildHitPathScreen(AX, AY: Integer;
  APath: TList): TNXHitTestResult;
var
  lChildClipRect: TNXRect;
  lControl: TNXControl;
  lHitResult: TNXHitTestResult;
  lHitRect: TNXRect;
  lLocalPoint: TNXPoint;
  lPathCount: Integer;
begin
  Result := htNone;
  if not Assigned(APath) then
    Exit;

  APath.Clear;

  if Self is TNXControl then
  begin
    lControl := TNXControl(Self);
    if (not lControl.IsEffectivelyVisible) or
      (not NXRectContainsPoint(lControl.AbsEffectiveHitRect, AX, AY)) then
      Exit;

    if not lControl.IsEffectivelyEnabled then
    begin
      Result := htBlocked;
      Exit;
    end;

    APath.Add(lControl);
    lPathCount := APath.Count;
    if HitTestChildren then
    begin
      lHitRect := lControl.AbsEffectiveHitRect;
      lChildClipRect := NXRectIntersect(lHitRect, AbsChildClipRect);
      lHitResult := HitTestChildrenScreen(AX, AY, lChildClipRect, APath);
      if lHitResult = htTarget then
      begin
        Result := htTarget;
        Exit;
      end;

      if lHitResult = htBlocked then
      begin
        APath.Clear;
        Result := htBlocked;
        Exit;
      end;
    end;

    if APath.Count > lPathCount then
    begin
      Result := htTarget;
      Exit;
    end;

    lLocalPoint := lControl.ScreenToLocal(AX, AY);
    if lControl.HitTestSelf(lLocalPoint.x, lLocalPoint.y) then
    begin
      Result := htTarget;
      Exit;
    end;

    APath.Clear;
    Exit;
  end;

  if HitTestChildren then
    Result := HitTestChildrenScreen(AX, AY, AbsChildClipRect, APath);
end;

procedure TNXControlHost.DispatchMouseDownScreen(AX, AY: Integer;
  AButton: TNXMouseButton);
var
  lCapturedControl: TNXControl;
  lFocusControl: TNXControl;
  lHitResult: TNXHitTestResult;
  lPath: TList;
  lPoint: TNXPoint;
begin
  if AButton = mbNone then
    Exit;

  lCapturedControl := NXCapturedMouseControl;
  if Assigned(lCapturedControl) then
  begin
    if not lCapturedControl.IsInputEligible then
    begin
      GCapturedMouseControl := nil;
      ClearPressedPath(AButton);
    end
    else
    begin
      FPressedControls[AButton] := lCapturedControl;
      lPoint := lCapturedControl.ScreenToLocal(AX, AY);
      lCapturedControl.ProcessMouseDown(lPoint.x, lPoint.y, AButton);
      Exit;
    end;
  end;

  lPath := TList.Create;
  try
    lHitResult := BuildHitPathScreen(AX, AY, lPath);
    if lHitResult = htBlocked then
      Exit;

    lFocusControl := FocusableControlFromPath(lPath);
    if Assigned(lFocusControl) then
      lFocusControl.Focus
    else
      ClearChildFocus;

    if lPath.Count = 0 then
      Exit;

    FPressedControls[AButton] := TNXControl(lPath[lPath.Count - 1]);
    StorePressedPath(AButton, lPath);
    DeliverMouseDownPath(lPath, AX, AY, AButton);
  finally
    lPath.Free;
  end;
end;

procedure TNXControlHost.DispatchMouseMotionScreen(AX, AY: Integer;
  AButtonState: TNXMouseButtons);
var
  lCapturedControl: TNXControl;
  lPath: TList;
  lPoint: TNXPoint;
begin
  lCapturedControl := NXCapturedMouseControl;
  if Assigned(lCapturedControl) then
  begin
    if not lCapturedControl.IsInputEligible then
    begin
      GCapturedMouseControl := nil;
    end
    else
    begin
      lPoint := lCapturedControl.ScreenToLocal(AX, AY);
      lCapturedControl.ProcessMouseMotion(lPoint.x, lPoint.y, AButtonState);
      Exit;
    end;
  end;

  lPath := TList.Create;
  try
    BuildHitPathScreen(AX, AY, lPath);
    SetHoverPath(lPath);

    if lPath.Count = 0 then
      Exit;

    DeliverMouseMotionPath(lPath, AX, AY, AButtonState);
  finally
    lPath.Free;
  end;
end;

procedure TNXControlHost.DispatchMouseUpScreen(AX, AY: Integer;
  AButton: TNXMouseButton);
var
  lCapturedControl: TNXControl;
  lHitResult: TNXHitTestResult;
  lPath: TList;
  lPoint: TNXPoint;
  lPressedPath: TList;
  lTarget: TNXControl;
begin
  if AButton = mbNone then
    Exit;

  lCapturedControl := NXCapturedMouseControl;
  if Assigned(lCapturedControl) then
  begin
    if not lCapturedControl.IsInputEligible then
    begin
      GCapturedMouseControl := nil;
      ClearPressedPath(AButton);
      Exit;
    end;

    FPressedControls[AButton] := lCapturedControl;
    lPoint := lCapturedControl.ScreenToLocal(AX, AY);
    lCapturedControl.ProcessMouseUp(lPoint.x, lPoint.y, AButton);
    ClearPressedPath(AButton);
    Exit;
  end;

  lTarget := FPressedControls[AButton];
  lPressedPath := FPressedPaths[AButton];
  if Assigned(lTarget) then
  begin
    if not lTarget.IsInputEligible then
    begin
      ClearPressedPath(AButton);
      Exit;
    end;

    if Assigned(lPressedPath) and (lPressedPath.Count > 0) then
      DeliverMouseUpPath(lPressedPath, AX, AY, AButton)
    else
    begin
      lPoint := lTarget.ScreenToLocal(AX, AY);
      lTarget.ProcessMouseUp(lPoint.x, lPoint.y, AButton);
    end;
    ClearPressedPath(AButton);
    Exit;
  end;

  lPath := TList.Create;
  try
    lHitResult := BuildHitPathScreen(AX, AY, lPath);
    if lHitResult = htBlocked then
      Exit;

    if lPath.Count > 0 then
      DeliverMouseUpPath(lPath, AX, AY, AButton);
  finally
    lPath.Free;
  end;
end;

procedure TNXControlHost.DispatchMouseWheelScreen(AX, AY, ADeltaX,
  ADeltaY: Integer);
var
  lPath: TList;
begin
  lPath := TList.Create;
  try
    BuildHitPathScreen(AX, AY, lPath);
    DeliverMouseWheelPath(lPath, AX, AY, ADeltaX, ADeltaY);
  finally
    lPath.Free;
  end;
end;

procedure TNXControlHost.FocusChild(AChild: TNXControl);
begin
end;

procedure TNXControlHost.FreeChild(AChild: TNXControl);
var
  lIndex: Integer;
begin
  if (not Assigned(FChildren)) or (not Assigned(AChild)) then
    Exit;

  lIndex := Children.IndexOf(AChild);
  if lIndex < 0 then
    Exit;

  Children.Delete(lIndex);
end;

function TNXControlHost.HasPressedControl(AButton: TNXMouseButton): Boolean;
begin
  Result := Assigned(FPressedControls[AButton]);
  if Result then
    Result := FPressedControls[AButton].IsInputEligible;
end;

function TNXControlHost.IsChildEffectivelyEnabled(
  AChild: TNXControl): Boolean;
begin
  Result := True;
end;

function TNXControlHost.IsChildEffectivelyVisible(
  AChild: TNXControl): Boolean;
begin
  Result := True;
end;

function TNXControlHost.GetCanvas: TNXCanvas;
begin
  Result := FCanvas;
end;

function TNXControlHost.GetChildOriginX(AChild: TNXControl): Integer;
begin
  Result := GetChildAreaLeft;
end;

function TNXControlHost.GetChildOriginY(AChild: TNXControl): Integer;
begin
  Result := GetChildAreaTop;
end;

function TNXControlHost.GetChildLayoutHeight(AChild: TNXControl): Integer;
begin
  Result := GetChildAreaHeight;
end;

function TNXControlHost.GetChildLayoutWidth(AChild: TNXControl): Integer;
begin
  Result := GetChildAreaWidth;
end;

function TNXControlHost.GetChildren: TNXControlList;
begin
  Result := FChildren;
end;

function TNXControlHost.ControlContains(AParent, AControl: TNXControl): Boolean;
var
  lIndex: Integer;
begin
  Result := False;
  if (not Assigned(AParent)) or (not Assigned(AControl)) then
    Exit;

  if AParent = AControl then
  begin
    Result := True;
    Exit;
  end;

  for lIndex := 0 to AParent.Children.Count - 1 do
  begin
    if ControlContains(AParent.Children[lIndex], AControl) then
    begin
      Result := True;
      Exit;
    end;
  end;
end;

function TNXControlHost.HitTestChildren: Boolean;
begin
  Result := True;
end;

function TNXControlHost.HitTestChildrenScreen(AX, AY: Integer;
  const AClipRect: TNXRect; APath: TList): TNXHitTestResult;
var
  lChild: TNXControl;
  lChildClipRect: TNXRect;
  lHitRect: TNXRect;
  lHitResult: TNXHitTestResult;
  lIndex: Integer;
  lLocalPoint: TNXPoint;
  lPathCount: Integer;
begin
  Result := htNone;
  if NXRectIsEmpty(AClipRect) or
    (not NXRectContainsPoint(AClipRect, AX, AY)) then
    Exit;

  for lIndex := Children.Count - 1 downto 0 do
  begin
    lChild := Children[lIndex];
    if (not Assigned(lChild)) or (not lChild.IsEffectivelyVisible) then
      Continue;

    lHitRect := NXRectIntersect(AClipRect, lChild.AbsHitRect);
    if not NXRectContainsPoint(lHitRect, AX, AY) then
      Continue;

    if not lChild.IsEffectivelyEnabled then
    begin
      Result := htBlocked;
      Exit;
    end;

    lPathCount := APath.Count;
    APath.Add(lChild);

    if lChild.HitTestChildren then
    begin
      lChildClipRect := NXRectIntersect(lHitRect, lChild.AbsChildClipRect);
      lHitResult := lChild.HitTestChildrenScreen(AX, AY, lChildClipRect, APath);
      if lHitResult = htTarget then
      begin
        Result := htTarget;
        Exit;
      end;

      if lHitResult = htBlocked then
      begin
        while APath.Count > lPathCount do
          APath.Delete(APath.Count - 1);
        Result := htBlocked;
        Exit;
      end;
    end;

    lLocalPoint := lChild.ScreenToLocal(AX, AY);
    if lChild.HitTestSelf(lLocalPoint.x, lLocalPoint.y) then
    begin
      Result := htTarget;
      Exit;
    end;

    while APath.Count > lPathCount do
      APath.Delete(APath.Count - 1);
  end;
end;

function TNXControlHost.HitTestScreen(AX, AY: Integer): TNXControl;
var
  lPath: TList;
begin
  Result := nil;
  lPath := TList.Create;
  try
    BuildHitPathScreen(AX, AY, lPath);
    if lPath.Count > 0 then
      Result := TNXControl(lPath[lPath.Count - 1]);
  finally
    lPath.Free;
  end;
end;

function TNXControlHost.HitTestSelf(AX, AY: Integer): Boolean;
begin
  Result := False;
end;

function TNXControlHost.LocalToScreen(AX, AY: Integer): TNXPoint;
begin
  Result := MakeNXPoint(AbsLeft + AX, AbsTop + AY);
end;

procedure TNXControlHost.LayoutChildren;
var
  lBottom: Integer;
  lChild: TNXControl;
  lIndex: Integer;
  lLeft: Integer;
  lRight: Integer;
  lTop: Integer;
begin
  if FLayouting then
    Exit;

  FLayouting := True;
  try
    lLeft := 0;
    lTop := 0;
    lRight := GetChildAreaWidth;
    lBottom := GetChildAreaHeight;

    for lIndex := 0 to Children.Count - 1 do
    begin
      lChild := Children[lIndex];
      if (not lChild.Visible) or (lChild.Align in [caNone, caClient]) then
        Continue;

      case lChild.Align of
        caTop:
        begin
          lChild.SetBoundsInternal(lLeft, lTop, Max(0, lRight - lLeft),
            lChild.Height, False);
          Inc(lTop, lChild.Height);
        end;
        caBottom:
        begin
          Dec(lBottom, lChild.Height);
          lChild.SetBoundsInternal(lLeft, lBottom, Max(0, lRight - lLeft),
            lChild.Height, False);
        end;
        caLeft:
        begin
          lChild.SetBoundsInternal(lLeft, lTop, lChild.Width,
            Max(0, lBottom - lTop), False);
          Inc(lLeft, lChild.Width);
        end;
        caRight:
        begin
          Dec(lRight, lChild.Width);
          lChild.SetBoundsInternal(lRight, lTop, lChild.Width,
            Max(0, lBottom - lTop), False);
        end;
      end;
    end;

    for lIndex := 0 to Children.Count - 1 do
    begin
      lChild := Children[lIndex];
      if (not lChild.Visible) or (lChild.Align <> caClient) then
        Continue;

      lChild.SetBoundsInternal(lLeft, lTop, Max(0, lRight - lLeft),
        Max(0, lBottom - lTop), False);
    end;

    FLayoutLeft := lLeft;
    FLayoutTop := lTop;
    FLayoutRight := lRight;
    FLayoutBottom := lBottom;

    for lIndex := 0 to Children.Count - 1 do
    begin
      lChild := Children[lIndex];
      if lChild.Align = caNone then
        lChild.ParentSizeCallback(GetChildLayoutWidth(lChild),
          GetChildLayoutHeight(lChild));
    end;
  finally
    FLayouting := False;
  end;
end;

procedure TNXControlHost.SendSizeCallback;
begin
  LayoutChildren;
end;

function TNXControlHost.ScreenToLocal(AX, AY: Integer): TNXPoint;
begin
  Result := MakeNXPoint(AX - AbsLeft, AY - AbsTop);
end;

procedure TNXControlHost.SetCanvas(ACanvas: TNXCanvas);
var
  lIndex: Integer;
begin
  FCanvas := ACanvas;

  for lIndex := 0 to Children.Count - 1 do
    Children[lIndex].Canvas := ACanvas;
end;

procedure TNXControl.SetParent(const AParent: INXControlParent);
begin
  FParent := AParent;
  if not Assigned(Parent) or not Assigned(Parent.Canvas) then
    Exit;

  SetCanvas(Parent.Canvas);
  SetBoundsInternal(Left, Top, Width, Height, True);
  ParentSizeCallback(Parent.GetChildLayoutWidth(Self),
    Parent.GetChildLayoutHeight(Self));
  PropagateParentContext;
end;

procedure TNXControl.PropagateParentContext;
var
  lIndex: Integer;
begin
  for lIndex := 0 to Children.Count - 1 do
  begin
    Children[lIndex].SetCanvas(Canvas);
    Children[lIndex].SetParent(INXControlParent(Self));
  end;
end;

procedure TNXControl.Paint;
var
  lIndex: Integer;
begin
  if Assigned(Canvas) and Visible then
  begin
    Canvas.PushClip(AbsBoundsRect);
    try
      Render;

      Canvas.PushClip(AbsClientRect);
      try
        for lIndex := 0 to Children.Count - 1 do
          Children[lIndex].Paint;
      finally
        Canvas.PopClip;
      end;
    finally
      Canvas.PopClip;
    end;
  end;
end;

procedure TNXControl.ParentSizeCallback(AWidth, AHeight: Integer);
var
  lHeight: Integer;
  lLeft: Integer;
  lTop: Integer;
  lWidth: Integer;
begin
  if Align <> caNone then
    Exit;

  lLeft := Left;
  lTop := Top;
  lWidth := Width;
  lHeight := Height;

  if (ancLeft in Anchors) and (ancRight in Anchors) then
    lWidth := Max(0, AWidth - FAnchorLeft - FAnchorRight)
  else if (ancRight in Anchors) and not (ancLeft in Anchors) then
    lLeft := AWidth - FAnchorRight - Width;

  if (ancTop in Anchors) and (ancBottom in Anchors) then
    lHeight := Max(0, AHeight - FAnchorTop - FAnchorBottom)
  else if (ancBottom in Anchors) and not (ancTop in Anchors) then
    lTop := AHeight - FAnchorBottom - Height;

  SetBoundsInternal(lLeft, lTop, lWidth, lHeight, False);
end;

procedure TNXControl.Render;
var
  lClipRect: TNXRect;
  lRect: TNXRect;
begin
  if not Visible then
    Exit;

  lRect := MakeNXRect(0, 0, Width, Height);

  case FFillStyle of
    FS_Filled:
      RenderFilledRect(lRect, CurFillColor);
    FS_None:
    begin
    end;
  end;

  lClipRect := AbsClientRect;
  Canvas.PushClip(lClipRect);
  try
    RenderClient;
  finally
    Canvas.PopClip;
  end;

  case FBorderStyle of
    BS_Single:
      RenderRect(lRect, CurBorderColor);
  end;
end;

procedure TNXControl.AttachToParent(const AParent: INXControlParent);
begin
  if Assigned(AParent) then
    AParent.AddChild(Self);
end;

constructor TNXControl.Create(const AParent: INXControlParent);
var
  lSkin: TNXSkin;
begin
  inherited Create;
  lSkin := nil;
  if Assigned(AParent) then
    lSkin := AParent.Skin
  else if Assigned(Application) then
    lSkin := Application.Skin;

  FHeight := 256;
  FWidth := 256;
  FHasLastClick := False;
  FLastClickButton := mbNone;
  FLastClickTicks := 0;
  FLastClickX := 0;
  FLastClickY := 0;
  FAlign := caNone;
  FAnchors := [ancLeft, ancTop];
  ReceiveAllEvents := False;
  CanFocus := True;
  TabStop := True;
  FEnabled := True;
  FVisible := True;
  if Assigned(lSkin) then
  begin
    ForeColor := lSkin.ForeColor;
    BackColor := lSkin.BackColor;
    BorderColor := lSkin.BorderColor;
    ActiveColor := lSkin.ActiveColor;
  end;
  BorderStyle := BS_None;
  FillStyle := FS_Filled;
  SkinClass := '';
  AttachToParent(AParent);
end;

constructor TNXControl.Create(const AParent: INXControlParent; const ARect: TNXRect);
begin
  Create(AParent);
  Left := ARect.x;
  Top := ARect.y;
  Width := ARect.w;
  Height := ARect.h;
end;

destructor TNXControl.Destroy;
begin
  FDestroying := True;

  if Assigned(Parent) then
    Parent.ChildDestroying(Self);

  if GCapturedMouseControl = Self then
    GCapturedMouseControl := nil;

  inherited Destroy;
end;

procedure TNXControl.ChildDestroying(AChild: TNXControl);
begin
  inherited ChildDestroying(AChild);

  if Assigned(Parent) then
    Parent.ChildDestroying(AChild);
end;

procedure TNXControl.ChildInputStateChanged(AChild: TNXControl);
begin
  inherited ChildInputStateChanged(AChild);

  if Assigned(Parent) then
    Parent.ChildInputStateChanged(AChild);
end;

procedure TNXControl.Focus;
begin
  if (not CanFocus) or (not IsInputEligible) then
    Exit;

  if Assigned(Parent) then
    Parent.FocusChild(Self)
  else
    IsFocused := True;
end;

procedure TNXControl.FocusChild(AChild: TNXControl);
begin
  if Assigned(Parent) then
    Parent.FocusChild(AChild);
end;

procedure TNXControl.CaptureMouse;
begin
  GCapturedMouseControl := Self;
end;

procedure TNXControl.ReleaseMouseCapture;
begin
  if GCapturedMouseControl = Self then
    GCapturedMouseControl := nil;
end;

function TNXControl.HasMouseCapture: Boolean;
begin
  Result := GCapturedMouseControl = Self;
end;

procedure TNXControl.SetWidth(AWidth: integer);
begin
  SetBoundsInternal(Left, Top, AWidth, Height, True);
  if (Align <> caNone) and Assigned(Parent) then
    Parent.LayoutChildren;
end;

procedure TNXControl.SetHeight(AHeight: integer);
begin
  SetBoundsInternal(Left, Top, Width, AHeight, True);
  if (Align <> caNone) and Assigned(Parent) then
    Parent.LayoutChildren;
end;

procedure TNXControl.SetAlign(AValue: TNXControlAlign);
begin
  if FAlign = AValue then
    Exit;

  FAlign := AValue;
  SetBoundsInternal(Left, Top, Width, Height, True);
  if Assigned(Parent) then
    Parent.LayoutChildren;
end;

procedure TNXControl.SetAnchors(AValue: TNXControlAnchors);
begin
  FAnchors := AValue;
  SetBoundsInternal(Left, Top, Width, Height, True);
end;

procedure TNXControl.SetEnabled(AValue: Boolean);
begin
  if FEnabled = AValue then
    Exit;

  FEnabled := AValue;
  if not FEnabled then
    ChildInputStateChanged(Self);
end;

procedure TNXControl.SetVisible(AValue: Boolean);
begin
  if FVisible = AValue then
    Exit;

  FVisible := AValue;
  if not FVisible then
    ChildInputStateChanged(Self);

  if Assigned(Parent) then
    Parent.LayoutChildren;
end;

procedure TNXControl.BringToFront;
var
  lIndex: Integer;
begin
  if not Assigned(Parent) then
    Exit;

  lIndex := Parent.Children.IndexOf(Self);
  if (lIndex >= 0) and (lIndex < Parent.Children.Count - 1) then
    Parent.Children.Move(lIndex, Parent.Children.Count - 1);
end;

function TNXControl.GetAbsLeft: integer;
begin
  if Parent = nil then
    Result := 0
  else
    Result := Parent.AbsLeft + Parent.GetChildOriginX(Self) + Left;
end;

function TNXControl.GetAbsTop: integer;
begin
  if Parent = nil then
    Result := 0
  else
    Result := Parent.AbsTop + Parent.GetChildOriginY(Self) + Top;
end;

function TNXControl.GetAbsBoundsRect: TNXRect;
begin
  Result := MakeNXRect(AbsLeft, AbsTop, Max(0, Width), Max(0, Height));
end;

function TNXControl.GetAbsEffectiveHitRect: TNXRect;
begin
  Result := AbsHitRect;
  if Assigned(Parent) then
    Result := NXRectIntersect(Result, Parent.GetAbsChildClipRect);
end;

function TNXControl.GetAbsContentRect: TNXRect;
begin
  Result := AbsClientRect;
end;

function TNXControl.GetAbsClientRect: TNXRect;
var
  lClientRect: TNXRect;
begin
  lClientRect := ClientRect;
  Result := MakeNXRect(AbsLeft + lClientRect.x, AbsTop + lClientRect.y,
    lClientRect.w, lClientRect.h);
end;

function TNXControl.GetBoundsRect: TNXRect;
begin
  Result := MakeNXRect(Left, Top, Max(0, Width), Max(0, Height));
end;

function TNXControl.GetChildAreaLeft: Integer;
begin
  Result := ContentRect.x;
end;

function TNXControl.GetChildAreaTop: Integer;
begin
  Result := ContentRect.y;
end;

function TNXControl.GetChildAreaHeight: Integer;
begin
  Result := ContentRect.h;
end;

function TNXControl.GetChildAreaWidth: Integer;
begin
  Result := ContentRect.w;
end;

function TNXControl.GetClientRect: TNXRect;
begin
  Result := GetContentRect;
end;

function TNXControl.GetBorderThickness: Integer;
begin
  case FBorderStyle of
    BS_Single:
      Result := 1;
  else
    Result := 0;
  end;
end;

function TNXControl.GetContentRect: TNXRect;
var
  lBorderThickness: Integer;
begin
  lBorderThickness := GetBorderThickness;
  Result := MakeNXRect(lBorderThickness, lBorderThickness,
    Max(0, Width - (lBorderThickness * 2)),
    Max(0, Height - (lBorderThickness * 2)));
end;

function TNXControl.GetFont: TNXFont;
begin
  Result := FFont;

  if (Result = nil) and (Parent <> nil) then
    Result := Parent.FontForChildren;

  if FMetricFont <> Result then
    UpdateFontMetrics(Result);
end;

function TNXControl.GetFontForChildren: TNXFont;
begin
  Result := Font;
end;

function TNXControl.GetHeight: Integer;
begin
  Result := FHeight;
end;

function TNXControl.GetLeft: Integer;
begin
  Result := FLeft;
end;

function TNXControl.GetPlatform: TNXPlatform;
begin
  Result := nil;
  if Assigned(Canvas) then
    Result := Canvas.Platform;
end;

function TNXControl.GetSkin: TNXSkin;
begin
  Result := nil;

  if Assigned(Parent) then
    Result := Parent.Skin
  else if Assigned(Application) then
    Result := Application.Skin;
end;

function TNXControl.GetTop: Integer;
begin
  Result := FTop;
end;

function TNXControl.GetWidth: Integer;
begin
  Result := FWidth;
end;

procedure TNXControl.SetLeft(AValue: Integer);
begin
  SetBoundsInternal(AValue, Top, Width, Height, True);
end;

procedure TNXControl.SetTop(AValue: Integer);
begin
  SetBoundsInternal(Left, AValue, Width, Height, True);
end;

procedure TNXControl.SetBoundsInternal(ALeft, ATop, AWidth, AHeight: Integer;
  AUpdateAnchors: Boolean);
var
  lResized: Boolean;
begin
  lResized := (FWidth <> AWidth) or (FHeight <> AHeight);

  FLeft := ALeft;
  FTop := ATop;
  FWidth := AWidth;
  FHeight := AHeight;

  if AUpdateAnchors and Assigned(Parent) then
  begin
    FAnchorLeft := Left;
    FAnchorTop := Top;
    FAnchorRight := Parent.GetChildLayoutWidth(Self) - (Left + Width);
    FAnchorBottom := Parent.GetChildLayoutHeight(Self) - (Top + Height);
  end;

  if lResized then
  begin
    ProcessResize;
    SendSizeCallback;
  end;
end;

procedure TNXControl.SetBounds(ALeft, ATop, AWidth, AHeight: Integer);
begin
  SetBoundsInternal(ALeft, ATop, AWidth, AHeight, True);
  if (Align <> caNone) and Assigned(Parent) then
    Parent.LayoutChildren;
end;

procedure TNXControl.SetBackColor(InColor: TNXColor);
begin
  FBackColor := InColor;
  CurFillColor := InColor;
end;

procedure TNXControl.SetBorderColor(InColor: TNXColor);
begin
  FBorderColor := InColor;
  CurBorderColor := InColor;
end;

procedure TNXControl.SetFont(AFont: TNXFont);
begin
  FFont := AFont;
  UpdateFontMetrics(Font);
  ctrl_FontChanged;
end;

procedure TNXControl.UpdateFontMetrics(AFont: TNXFont);
begin
  FMetricFont := AFont;

  if AFont = nil then
  begin
    FontHeight := 0;
    FontAscent := 0;
    FontDescent := 0;
    FontLineSkip := 0;
    FontMonospace := 0;
    Exit;
  end;

  FontHeight := AFont.Height;
  FontAscent := AFont.Ascent;
  FontDescent := AFont.Descent;
  FontLineSkip := AFont.LineSkip;
  FontMonospace := Ord(AFont.IsMonospace);
end;

function TNXControl.LocalRectToAbs(const ARect: TNXRect): TNXRect;
begin
  Result := MakeNXRect(AbsLeft + ARect.x, AbsTop + ARect.y, ARect.w, ARect.h);
end;

procedure TNXControl.RenderRect(const ARect: TNXRect; AColor: TNXColor);
begin
  Canvas.DrawRect(LocalRectToAbs(ARect), AColor);
end;

procedure TNXControl.RenderFilledRect(const ARect: TNXRect; AColor: TNXColor);
begin
  Canvas.FillRect(LocalRectToAbs(ARect), AColor);
end;

procedure TNXControl.RenderLine(AX0, AY0, AX1, AY1: Integer; AColor: TNXColor);
begin
  Canvas.DrawLine(AbsLeft + AX0, AbsTop + AY0, AbsLeft + AX1,
    AbsTop + AY1, AColor);
end;

procedure TNXControl.RenderText(AText: string; AX, AY: Integer;
  AAlignment: TTextAlign);
var
  lNXFont: TNXFont;
  lTextWidth: Integer;
  lTextX: Integer;
begin
  if AText = '' then
    Exit;

  lNXFont := Font;
  if not Assigned(lNXFont) then
    raise Exception.Create('RenderText called on [' + AText + '] but no Font Set');

  lTextWidth := Canvas.TextWidth(AText, lNXFont);

  case AAlignment of
    Align_Left:
      lTextX := AbsLeft + AX;
    Align_Center:
      lTextX := AbsLeft + AX - (lTextWidth div 2);
    Align_Right:
      lTextX := AbsLeft + AX - lTextWidth;
  end;

  Canvas.DrawText(AText, lTextX, AbsTop + AY, FForeColor, lNXFont);
end;

procedure TNXControl.RenderClient;
begin
end;

function TNXControl.HitTestSelf(AX, AY: Integer): Boolean;
begin
  Result := ContainsLocalPoint(AX, AY);
end;

procedure TNXControl.ctrl_FontChanged;
begin
end;

procedure TNXControl.SetFocused(AValue: Boolean);
begin
  if AValue then
  begin
    if (not FFocused) and CanFocus and IsInputEligible then
    begin
      FFocused := True;
      ProcessFocus;
    end;
  end
  else
  begin
    if FFocused then
    begin
      ProcessLoseFocus;
      ClearChildFocus;
      FFocused := False;
    end;
  end;
end;

procedure TNXControl.ChildAddedCallback;
begin

end;

function TNXControl.FindFocusableControlAt(X, Y: Integer): TNXControl;
var
  lHitResult: TNXHitTestResult;
  lPath: TList;
  lIndex: Integer;
  lPoint: TNXPoint;
begin
  Result := nil;
  if not IsInputEligible then
    Exit;

  lPoint := LocalToScreen(X, Y);
  lPath := TList.Create;
  try
    lHitResult := BuildHitPathScreen(lPoint.x, lPoint.y, lPath);
    if lHitResult = htBlocked then
      Exit;

    for lIndex := lPath.Count - 1 downto 0 do
    begin
      Result := TNXControl(lPath[lIndex]);
      if Result.IsInputEligible and Result.CanFocus then
        Exit;
    end;
  finally
    lPath.Free;
  end;

  if IsInputEligible and CanFocus then
    Result := Self;
end;

procedure TNXControl.ProcessMouseEnter;
begin
  FMouseEntered := True;
  DoMouseEnter;
end;

procedure TNXControl.ProcessMouseExit;
begin
  FMouseEntered := False;
  DoMouseExit;
end;

procedure TNXControl.ProcessMouseDown(X, Y: integer; Button: TNXMouseButton);
begin
  if Button = mbNone then
    Exit;

  Include(ButtonStates, Button);
  DoMouseDown(X, Y, Button);
end;

procedure TNXControl.ProcessMouseUp(X, Y: integer; Button: TNXMouseButton);
begin
  if Button = mbNone then
    Exit;

  if Button in ButtonStates then
  begin
    DoMouseUp(X, Y, Button);
    if HitTestSelf(X, Y) then
      ProcessMouseClick(X, Y, Button);
    Exclude(ButtonStates, Button);
  end
  else
    DoMouseUp(X, Y, Button);
end;

procedure TNXControl.ProcessMouseClick(X, Y: integer; Button: TNXMouseButton);
var
  lTicks: UInt32;
begin
  DoMouseClick(X, Y, Button);

  if Assigned(GetPlatform) then
    lTicks := GetPlatform.GetTicks
  else
    lTicks := 0;
  if FHasLastClick and (FLastClickButton = Button) and
    (lTicks - FLastClickTicks <= cDoubleClickMaxMS) and
    (Abs(X - FLastClickX) <= cDoubleClickMaxDistance) and
    (Abs(Y - FLastClickY) <= cDoubleClickMaxDistance) then
  begin
    FHasLastClick := False;
    DoMouseDoubleClick(X, Y, Button);
    Exit;
  end;

  FHasLastClick := True;
  FLastClickButton := Button;
  FLastClickTicks := lTicks;
  FLastClickX := X;
  FLastClickY := Y;
end;

procedure TNXControl.ProcessMouseMotion(X, Y: integer; ButtonState: TNXMouseButtons);
begin
  DoMouseMotion(X, Y, ButtonState);
end;

procedure TNXControl.ProcessMouseWheel(X, Y, ADeltaX, ADeltaY: Integer);
begin
  DoMouseWheel(X, Y, ADeltaX, ADeltaY);
end;

procedure TNXControl.ProcessTextInput(const AText: string);
begin
  DoTextInput(AText);
end;

procedure TNXControl.ProcessFocus;
begin
  DoFocus;
end;

procedure TNXControl.ProcessLoseFocus;
begin
  DoLoseFocus;
end;

procedure TNXControl.ProcessKeyDown(const AEvent: TNXKeyEventData);
begin
  DoKeyDown(AEvent);
end;

procedure TNXControl.ProcessKeyUp(const AEvent: TNXKeyEventData);
begin
  DoKeyUp(AEvent);
end;

procedure TNXControl.ProcessResize;
begin
  DoResize;
end;

function TNXControl.IsChildEffectivelyEnabled(AChild: TNXControl): Boolean;
begin
  Result := IsEffectivelyEnabled;
end;

function TNXControl.IsChildEffectivelyVisible(AChild: TNXControl): Boolean;
begin
  Result := IsEffectivelyVisible;
end;

function TNXControl.IsEffectivelyEnabled: Boolean;
begin
  Result := Enabled;
  if Result and Assigned(Parent) then
    Result := Parent.IsChildEffectivelyEnabled(Self);
end;

function TNXControl.IsEffectivelyVisible: Boolean;
begin
  Result := Visible;
  if Result and Assigned(Parent) then
    Result := Parent.IsChildEffectivelyVisible(Self);
end;

function TNXControl.IsInputEligible: Boolean;
begin
  Result := IsEffectivelyVisible and IsEffectivelyEnabled;
end;

procedure TNXControl.DoMouseEnter;
begin
  if Assigned(FOnMouseEnter) then
    FOnMouseEnter(Self);
end;

procedure TNXControl.DoMouseExit;
begin
  if Assigned(FOnMouseExit) then
    FOnMouseExit(Self);
end;

procedure TNXControl.DoMouseDown(X, Y: integer; Button: TNXMouseButton);
begin
  if Assigned(FOnMouseDown) then
    FOnMouseDown(Self, X, Y, Button);
end;

procedure TNXControl.DoMouseUp(X, Y: integer; Button: TNXMouseButton);
begin
  if Assigned(FOnMouseUp) then
    FOnMouseUp(Self, X, Y, Button);
end;

procedure TNXControl.DoMouseMotion(X, Y: integer; ButtonState: TNXMouseButtons);
begin
  if Assigned(FOnMouseMotion) then
    FOnMouseMotion(Self, X, Y, ButtonState);
end;

procedure TNXControl.DoMouseWheel(X, Y, ADeltaX, ADeltaY: Integer);
begin
  if Assigned(FOnMouseWheel) then
    FOnMouseWheel(Self, X, Y, ADeltaX, ADeltaY);
end;

procedure TNXControl.DoTextInput(const AText: string);
begin
  if Assigned(FOnTextInput) then
    FOnTextInput(Self, AText);
end;

procedure TNXControl.DoMouseClick(X, Y: integer; Button: TNXMouseButton);
begin
  if Assigned(FOnMouseClick) then
    FOnMouseClick(Self, X, Y, Button);
end;

procedure TNXControl.DoMouseDoubleClick(X, Y: integer; Button: TNXMouseButton);
begin
  if Assigned(FOnMouseDoubleClick) then
    FOnMouseDoubleClick(Self, X, Y, Button);
end;

procedure TNXControl.DoFocus;
begin
  if Assigned(FOnFocus) then
    FOnFocus(Self);
end;

procedure TNXControl.DoLoseFocus;
begin
  if Assigned(FOnLoseFocus) then
    FOnLoseFocus(Self);
end;

procedure TNXControl.DoKeyDown(const AEvent: TNXKeyEventData);
begin
  if Assigned(FOnKeyDown) then
    FOnKeyDown(Self, AEvent);
end;

procedure TNXControl.DoKeyUp(const AEvent: TNXKeyEventData);
begin
  if Assigned(FOnKeyUp) then
    FOnKeyUp(Self, AEvent);
end;

procedure TNXControl.DoResize;
begin
  if Assigned(FOnResize) then
    FOnResize(Self);
end;

end.
