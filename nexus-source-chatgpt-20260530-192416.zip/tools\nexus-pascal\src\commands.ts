import * as vscode from 'vscode';
import { LazarusProjectCommandHandler } from './commandHandlers/lazarusProjectCommandHandler';
import { LanguageServerCommandHandler } from './commandHandlers/languageServerCommandHandler';
import { LazarusTestModuleCommandHandler } from './commandHandlers/lazarusTestModuleCommandHandler';
import { TemplateCommandHandler } from './commandHandlers/templateCommandHandler';
import { LanguageClientHandle } from './services/languageClientHandle';
import { ExtensionPaths } from './services/extensionPaths';

export class FpcCommandManager {
    private readonly templateCommands: TemplateCommandHandler;
    private readonly languageServerCommands: LanguageServerCommandHandler;
    private readonly lazarusTestModuleCommands: LazarusTestModuleCommandHandler;
    private readonly lazarusProjectCommands: LazarusProjectCommandHandler;

    public constructor(
        workspaceRoot: string,
        extensionPaths: ExtensionPaths,
        languageClient: LanguageClientHandle
    ) {
        this.templateCommands = new TemplateCommandHandler(workspaceRoot, extensionPaths, languageClient);
        this.languageServerCommands = new LanguageServerCommandHandler(languageClient);
        this.lazarusTestModuleCommands = new LazarusTestModuleCommandHandler(workspaceRoot);
        this.lazarusProjectCommands = new LazarusProjectCommandHandler();
    }

    public registerAll(context: vscode.ExtensionContext): void {
        this.templateCommands.register(context);
        this.languageServerCommands.register(context);
        this.lazarusTestModuleCommands.register(context);
        this.lazarusProjectCommands.register(context);
    }
}
