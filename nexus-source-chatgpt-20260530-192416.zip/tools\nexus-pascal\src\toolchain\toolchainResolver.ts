import * as cp from 'child_process';
import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';

export interface PascalToolchainResolution {
    compilerPath?: string;
    lazarusDirectory?: string;
    fpcSourceDirectory?: string;
}

export type ToolchainEnvironment = Record<string, string | undefined>;

export function resolvePascalToolchain(): PascalToolchainResolution {
    const toolchainConfig = vscode.workspace.getConfiguration('nexusPascal.toolchain');
    const configuredCompilerPath = cleanPath(toolchainConfig.get<string>('compilerPath'));
    const configuredLazarusDirectory = cleanPath(toolchainConfig.get<string>('lazarusDirectory'));
    const lazarusDirectory = existingDirectory(configuredLazarusDirectory);
    const compilerPath = configuredCompilerPath
        || findCompilerInLazarus(lazarusDirectory);
    const fpcSourceDirectory = findFpcSourceDirectory(lazarusDirectory, compilerPath);

    return {
        compilerPath,
        lazarusDirectory,
        fpcSourceDirectory
    };
}

export function createToolchainEnvironment(
    toolchain: PascalToolchainResolution = resolvePascalToolchain()
): ToolchainEnvironment {
    const environment: ToolchainEnvironment = {};

    if (toolchain.compilerPath) {
        environment.PP = toolchain.compilerPath;
    }
    if (toolchain.lazarusDirectory) {
        environment.LAZARUSDIR = toolchain.lazarusDirectory;
    }
    if (toolchain.fpcSourceDirectory) {
        environment.FPCDIR = toolchain.fpcSourceDirectory;
    }

    return environment;
}

function cleanPath(value: string | undefined): string | undefined {
    const result = value?.trim();
    return result ? result : undefined;
}

function existingDirectory(value: string | undefined): string | undefined {
    if (!value) {
        return undefined;
    }

    return fs.existsSync(value) && fs.lstatSync(value).isDirectory()
        ? path.resolve(value)
        : undefined;
}

function existingFile(value: string | undefined): string | undefined {
    if (!value) {
        return undefined;
    }

    return fs.existsSync(value) && fs.lstatSync(value).isFile()
        ? path.resolve(value)
        : undefined;
}

function firstExistingDirectory(candidates: string[]): string | undefined {
    for (const candidate of candidates) {
        const directory = existingDirectory(candidate);
        if (directory) {
            return directory;
        }
    }

    return undefined;
}

function firstExistingFile(candidates: string[]): string | undefined {
    for (const candidate of candidates) {
        const file = existingFile(candidate);
        if (file) {
            return file;
        }
    }

    return undefined;
}

function findCompilerInLazarus(lazarusDirectory: string | undefined): string | undefined {
    if (!lazarusDirectory) {
        return undefined;
    }

    const fpcRoot = path.join(lazarusDirectory, 'fpc');
    const executableName = process.platform === 'win32' ? 'fpc.exe' : 'fpc';
    const candidates: string[] = [];

    for (const versionDirectory of sortedChildDirectories(fpcRoot)) {
        candidates.push(
            path.join(versionDirectory, 'bin', hostFpcBinDirectory(), executableName),
            path.join(versionDirectory, 'bin', executableName)
        );
    }

    candidates.push(
        path.join(fpcRoot, 'bin', hostFpcBinDirectory(), executableName),
        path.join(fpcRoot, 'bin', executableName)
    );

    return firstExistingFile(candidates);
}

function findFpcSourceDirectory(
    lazarusDirectory: string | undefined,
    compilerPath: string | undefined
): string | undefined {
    const candidates: string[] = [];

    if (lazarusDirectory) {
        const fpcRoot = path.join(lazarusDirectory, 'fpc');
        for (const versionDirectory of sortedChildDirectories(fpcRoot)) {
            candidates.push(path.join(versionDirectory, 'source'));
        }

        candidates.push(
            path.join(fpcRoot, 'source'),
            path.join(lazarusDirectory, 'fpcsrc')
        );
    }

    if (compilerPath && path.isAbsolute(compilerPath)) {
        const versionDirectory = fpcVersionDirectoryFromCompiler(compilerPath);
        if (versionDirectory) {
            candidates.push(path.join(versionDirectory, 'source'));

            const versionRoot = path.dirname(versionDirectory);
            if (path.basename(versionRoot).toLowerCase() === 'fpc') {
                for (const siblingVersionDirectory of sortedChildDirectories(versionRoot)) {
                    candidates.push(path.join(siblingVersionDirectory, 'source'));
                }
            }
        }
    }

    const compilerVersion = readFpcVersion(compilerPath);
    if (compilerVersion) {
        candidates.push(...systemFpcSourceCandidates(compilerVersion));
    }

    return firstExistingDirectory(candidates);
}

function sortedChildDirectories(root: string): string[] {
    if (!root || !fs.existsSync(root) || !fs.lstatSync(root).isDirectory()) {
        return [];
    }

    return fs.readdirSync(root, { withFileTypes: true })
        .filter(entry => entry.isDirectory())
        .map(entry => path.join(root, entry.name))
        .sort((left, right) => right.localeCompare(left, undefined, {
            numeric: true,
            sensitivity: 'base'
        }));
}

function fpcVersionDirectoryFromCompiler(compilerPath: string): string | undefined {
    const compilerDirectory = path.dirname(compilerPath);
    if (path.basename(compilerDirectory).toLowerCase() === 'bin') {
        return path.dirname(compilerDirectory);
    }

    const binDirectory = path.dirname(compilerDirectory);
    if (path.basename(binDirectory).toLowerCase() === 'bin') {
        return path.dirname(binDirectory);
    }

    return undefined;
}

function hostFpcBinDirectory(): string {
    const cpu = process.arch === 'x64'
        ? 'x86_64'
        : process.arch === 'ia32'
            ? 'i386'
            : process.arch === 'arm64'
                ? 'aarch64'
                : process.arch;
    const os = process.platform === 'win32'
        ? process.arch === 'ia32' ? 'win32' : 'win64'
        : process.platform;

    return `${cpu}-${os}`;
}

function readFpcVersion(compilerPath: string | undefined): string | undefined {
    if (!compilerPath) {
        return undefined;
    }

    try {
        return cp.execFileSync(compilerPath, ['-iV'], {
            encoding: 'utf8',
            timeout: 5000,
            stdio: ['ignore', 'pipe', 'ignore']
        }).trim();
    } catch {
        return undefined;
    }
}

function systemFpcSourceCandidates(version: string): string[] {
    switch (process.platform) {
        case 'win32':
            return [
                path.join('C:\\lazarus', 'fpc', version, 'source')
            ];
        case 'darwin':
            return [
                path.join('/usr/local/share/fpcsrc', version),
                path.join('/opt/local/share/fpcsrc', version)
            ];
        default:
            return [
                path.join('/usr/share/fpcsrc', version),
                path.join('/usr/local/share/fpcsrc', version),
                path.join('/usr/share/fpc', version, 'source')
            ];
    }
}
