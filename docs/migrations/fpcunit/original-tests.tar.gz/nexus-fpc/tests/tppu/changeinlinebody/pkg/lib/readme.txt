Output folder for tests.
