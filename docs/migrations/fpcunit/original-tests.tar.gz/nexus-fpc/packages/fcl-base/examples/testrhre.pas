{$mode objfpc}
{$h+ }

{ test reverse host resolve }

program testrhre;

uses resolve,sysutils,Sockets;

Var
  I : integer;
  S : String;


begin
  If (ParamCount>0) then
    S:=Paramstr(1)
  else
    S:='212.224.143.202';
  With THostResolver.Create(Nil) do
    try
      If Not AddressLookup(S) then
        Writeln('Lookup failed : ',LastError)
      else
        begin
        Writeln('Name          : ',ResolvedName);
        Writeln('Address       : ',AddressAsString);
        Writeln('Address count : ',AddressCount);
        For I:=0 to AddressCount-1 do
          Writeln('Adress ',I:2,'     : ',HostAddrToStr(Addresses[I]));
        Writeln('Alias count   : ',AliasCount);
        For I:=0 to AliasCount-1 do
          Writeln('Alias ',i:2,'  : ',Aliases[I]);
        end;
    finally
       Free;
    end;
end.
