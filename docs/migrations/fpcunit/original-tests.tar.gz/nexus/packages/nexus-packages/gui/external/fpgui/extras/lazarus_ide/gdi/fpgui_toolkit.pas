{ This file was automatically created by Lazarus. Do not edit!
  This source is only used to compile and install the package.
 }

unit fpgui_toolkit;

{$warn 5023 off : no warning about unused units}
interface

uses
  fpg_base, fpg_main, fpg_cmdlineparams, fpg_command_intf, fpg_constants,
  fpg_extinterpolation, fpg_imagelist, fpg_imgfmt_bmp, fpg_pofiles,
  fpg_popupwindow, fpg_stdimages, fpg_translations,
  fpg_stringutils, fpg_utils, fpg_widget, fpg_wuline, fpg_impl, fpg_gdi,
  fpg_animation, fpg_basegrid, fpg_button, fpg_checkbox, fpg_combobox,
  fpg_customgrid, fpg_dialogs, fpg_editcombo, fpg_edit, fpg_form, fpg_gauge,
  fpg_grid, fpg_hyperlink, fpg_iniutils, fpg_label, fpg_listbox, fpg_listview,
  fpg_memo, fpg_menu, fpg_mru, fpg_panel, fpg_popupcalendar, fpg_progressbar,
  fpg_radiobutton, fpg_scrollbar, fpg_style, fpg_tab, fpg_trackbar, fpg_tree,
  fpgui_db, fpg_splitter, fpg_hint, fpg_spinedit, fpg_extgraphics,
  fpg_ColorMapping, fpg_ColorWheel, fpg_interface, fpg_editbtn,
  fpg_imgfmt_jpg, fpg_imgutils, fpg_stylemanager, fpg_style_win2k,
  fpg_style_motif, fpg_readonly, fpg_imgfmt_png, U_Command, U_Pdf, U_Report,
  U_ReportImages, U_Visu, fpg_trayicon, fpg_dbugintf, fpg_dbugmsg,
  fpg_style_carbon, fpg_style_plastic, fpg_style_fusion, fpg_style_win8, fpg_scrollframe, fpg_toggle,
  fpg_StringGridBuilder, fpg_CSVParser, fpg_ledmatrix, fpg_hexview,
  fpg_flowlayout, fpg_layoutmanager, fpg_layouttypes, fpg_borderlayout,
  fpg_miglayout, fpg_migconstraint, fpg_mig_hidemode, fpg_mig_unitvalue,
  fpg_mig_boundsize, fpg_mig_platformdefaults, fpg_mig_dimconstraint,
  fpg_mig_ac, fpg_mig_lc, fpg_mig_cc, fpg_mig_constraintparser,
  fpg_mig_resizeconstraint, fpg_mig_layoutcallback, fpg_mig_gapprovider, fpg_mig_linkhandler,
  fpg_mig_layoututil;

implementation

end.
